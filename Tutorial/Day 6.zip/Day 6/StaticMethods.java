class Student{
    int rollno;
    String name;
    
    // static String college = "IST";


    // static void change(){
    //     college = "BBDIT";
    // }


    static String module = "English";

    static void change(){
        module = "Communication Skills";
    }


    Student(int r, String n){ //constructor
        rollno = r;
        name = n;
    }

    void display(){
        System.out.println(rollno + " " + name + " " + module);
    }
}


class StaticMethods {
    public static void main(String args[]){
        Student s1 = new Student(111, "Sanjana");
        Student s2 = new Student(222, "Sewmini");
        Student s3 = new Student(333, "Samindi");

        Student.change();

        s1.display();
        s2.display();
        s3.display();
    }
}
