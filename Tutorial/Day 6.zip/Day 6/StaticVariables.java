class Student{
    int rollno; //instance variables
    String name; //instance variables
    static String college = "ITS"; // static variable

    Student(int r, String n){ //constructor
        rollno = r;
        name = n;
    }

    void display(){
        System.out.println(rollno + " " + name + " " + college);
    }
}

class StaticVariables{
    public static void main(String args []){
        Student s1 = new Student(111, "Sanjana");
        Student s2 = new Student(222, "Sewmini");

        s1.display();
        s2.display();
    }
}