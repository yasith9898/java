class Employee{
    int salary = 40000;
    String companyName = "aaaa";
}


class Programmer extends Employee {
    int bonus = 10000;

    public static void main( String args []){
        Programmer p = new Programmer();

        System.out.println("Salary is : " + p.salary);
        System.out.println("Bonus is : " + p.bonus);
        System.out.println("Company name is : " + p.companyName);
    }
}
