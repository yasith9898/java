public class StaticBlock {
    static{
        System.out.println("Static block invoked");
    }

    public static void main(String args[]){
        System.out.println("Hello World");
    }
}
