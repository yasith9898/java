class Animal{
    void eat(){
        System.out.println("Eating");
    }
}

class Dog extends Animal{
    void bark(){
        System.out.println("Barking");
    }
}

class Cat extends Animal{
    void meow(){
        System.out.println("Meowing");
    }
}

// class Puppy extends Dog{
//     void weep(){
//         System.out.println("Weeping");
//     }
// }

public class TestInheritance1 {
    public static void main (String args[]){
        //Puppy d = new Puppy();
        // d.weep();
        // d.bark();
        // d.eat();

        System.out.println("Cat");
        Cat c = new Cat();
        c.meow();
        c.eat();

        System.out.println("Dog");
        Dog d = new Dog();
        d.bark();
        d.eat();
    }
}
