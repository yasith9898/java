//this(): to invoke current class constructor
//
class B{
    B(){
        System.out.println("Hello B");
    }

    B(int x){
        this();
        System.out.println(x);
    }

}


public class This3 {
    public static void main (String args[]){
        B b = new B(10);
    }
}
