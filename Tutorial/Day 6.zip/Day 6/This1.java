// this: to refer current class instance variable

class Student{
    int rollno;
    String name;
    float fee;

    Student(int rollno, String name, float fee){
        this.rollno= rollno;
        this.name = name;
        this.fee = fee;
    }

    void display(){
        System.out.println(rollno + " " + name + " " + fee);
    }
}


class This1{
    public static void main(String args[]){
        Student s1 = new Student(111, "Sanjana", 10000f);
        Student s2 = new Student(222, "Sewmini", 10000f);
        Student s3 = new Student(333, "Samindi", 10000f);

        s1.display();
        s2.display();
        s3.display();
    }
}