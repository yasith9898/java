import java.util.Scanner;
class Circle{

    public static void Circle(){
        Scanner s = new Scanner(System.in);
        int radius;

        System.out.println("Enter a radius");
        radius = s.nextInt();

        System.out.println("Circumference is "+(2*3.14*radius) + " and the area is " + (3.14*radius*radius));
    }
public static void main(String args[]){
Circle();
}
}