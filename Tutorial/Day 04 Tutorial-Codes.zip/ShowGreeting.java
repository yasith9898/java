public class ShowGreeting {
    public static void main(String args[]) {
       int hour = 19;
       String greeting;

       if(hour>=21){
        greeting = "Good Night!";
       }

       else if(hour>=18){
        greeting = "Good Evening!";
       }

       else if(hour>=12){
        greeting = "Good Afternoon!";
       }

       else{
        greeting = "Good Morning";
       }

       System.out.println(greeting);
    }
}