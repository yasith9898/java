import java.util.Scanner;
public class Grades{
    public static void main(String args[]){
        int marks;
        char grade= '|';

        Scanner Grades = new Scanner(System.in);

        System.out.println("Input marks: ");
        marks = Grades.nextInt();

        if(marks>=0 && marks<= 100);
        if(marks>=75){
            grade = 'A';
        }

        else if(marks>=65){
            grade = 'B';
        }

        else if(marks>=55){
            grade = 'C';
        }

        else if(marks>=35){
            grade = 'S';
        }

        else{
            grade = 'F';
        }

        System.out.println("Your grade is "+grade);
    }
}